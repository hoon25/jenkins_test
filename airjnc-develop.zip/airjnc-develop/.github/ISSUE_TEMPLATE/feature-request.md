---
name: Feature Request
about: 기능 추가
title: Feature Request
labels: 'Type: Feature'
assignees: ''

---

# 추가해야 할 기능들은 무엇인가요?

-   [ ]

# 해당 기능이 왜 필요한가요?

# 기타

그 외로 적어야 할 것들을 적어주세요
