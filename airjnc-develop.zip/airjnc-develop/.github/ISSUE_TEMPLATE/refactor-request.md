---
name: Refactor Request
about: 리팩토링 필요
title: Refactor Request
labels: 'Type: Refactor'
assignees: ''

---

# 어느 부분을 리팩토링해야 하는가요?

# 적은 부분들을 왜 리팩토링해야 하는가요?

# 기타

그 외로 적어야 할 것들을 적어주세요
