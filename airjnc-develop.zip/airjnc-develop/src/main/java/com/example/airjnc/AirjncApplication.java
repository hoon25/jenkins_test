package com.example.airjnc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirjncApplication {

    public static void main(String[] args) {
        SpringApplication.run(AirjncApplication.class, args);
    }

}
